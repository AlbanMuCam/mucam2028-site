# Site MuCam2028 — 4 pages (statique)

Ce dossier contient un site statique minimal (HTML/CSS) prêt pour GitHub Pages (ou Netlify/Vercel).

## Structure
- `index.html` (Accueil)
- `projet.html` (Le projet)
- `quai-kleber.html` (15–16 quai Kléber)
- `participer.html` (Participer)
- `assets/` (style.css, logo.svg, favicon.svg)
- `docs/` — placez ici `dossier.pdf` et `note-de-synthese.pdf`
- `CNAME` (déclare le domaine `mucam2028.bzh` pour GitHub Pages)

## Déploiement gratuit via GitHub Pages
1. Créez un dépôt (par ex. `mucam2028-site`) et uploadez tous les fichiers.
2. Dans **Settings → Pages** : *Build and deployment* → **Deploy from a branch** ; *Branch* : `main` / `/ (root)`.
3. Dans **Settings → Pages → Custom domain** : assurez-vous que le fichier `CNAME` contient `mucam2028.bzh`.
4. Chez votre registrar, ajoutez ces enregistrements **A** pour le domaine racine :
   - 185.199.108.153
   - 185.199.109.153
   - 185.199.110.153
   - 185.199.111.153
   Et (si possible) ces **AAAA** :
   - 2606:50c0:8000::153
   - 2606:50c0:8001::153
   - 2606:50c0:8002::153
   - 2606:50c0:8003::153
5. Une fois publié, activez **Enforce HTTPS** dans *Settings → Pages*.

## Modifier le site
- Éditez le texte directement dans les fichiers `.html`.
- Ajoutez vos PDF dans `docs/` et mettez à jour les liens si le nom change.

© 2025 MuCam2028 — site statique minimal.
